package net.neoforged.fml;
final class FMLVersionProperties {
 private FMLVersionProperties() {}
 static final String VERSION = "11.0.26.0";
}
